<?php
// Silence is the best answer
?>